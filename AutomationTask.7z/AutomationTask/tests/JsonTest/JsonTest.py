from utilities.teststatus import TestStatus
import unittest
import pytest
from base.drivers import Drivers
import sys


sys.path.insert(0,'../..')

@pytest.mark.usefixtures()
class Test1(unittest.TestCase):

    @pytest.fixture(autouse=True)
    def classSetup(self):
        self.ts = TestStatus()
        self.base = Drivers(url='https://jsonplaceholder.typicode.com/comments')

    @pytest.mark.run(order=1)
    def test_validateNumberOfComments(self):
        validationResult = self.base.checkNumberOfCommentsForPostID(40, 5)
        self.ts.markFinal("test_validateNumberOfComments", validationResult, "Verify That Post ID 40 Contains 5 Comments")

    @pytest.mark.run(order=2)
    def test_validatePostIDContainComment(self):
        validateCommentResult = self.base.checkCommentExist(40, 199, "pariatur aspernatur nam atque quis",
                                                       "Cooper_Boehm@damian.biz",
                                                       "veniam eos ab voluptatem in fugiat ipsam quis\nofficiis non qui\nquia ut id voluptates et a molestiae commodi quam\ndolorem enim soluta impedit autem nulla")
        self.ts.markFinal("test_validatePostIDContainComment", validateCommentResult,
                          "Verify That Post ID 40 Contains Specific Comment")







