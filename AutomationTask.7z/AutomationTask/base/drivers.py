import requests

class Drivers():

    def __init__(self, url):
        self.URL = url

    def getJsonAPI(self):
        '''
        Get Json Request
        :return: Json API
        '''
        r = requests.get(self.URL)
        return r.json()

    def getNumberOfComments(self, postID):
        '''
        Calculate the number of comments with specific post ID
        :return: Number of comments in post ID
        '''
        numberOfComments = 0
        jsonAPI = self.getJsonAPI()
        for item in jsonAPI:
            if item["postId"] == postID:
                numberOfComments += 1

        return numberOfComments

    def checkNumberOfCommentsForPostID(self, postID, expectedCommentsNumber):
        '''
        Compare between the Actual and Expected number of comments for specific post ID
        :return: True if Actual equal Expected value
        and False otherwise
        '''
        acutalNumberOfComments = self.getNumberOfComments(postID)
        if expectedCommentsNumber == acutalNumberOfComments:
            return True
        else:
            return False

    def getCommentsOfSpecificPostId(self, postID):
        '''
        Get the list of comments for specific post ID
        :return: List of comments
        '''
        comments = []
        jsonAPI = self.getJsonAPI()
        for item in jsonAPI:
            if item["postId"] == postID:
                comments.append(item)

        return comments

    def verifyActualVSExpected(self, Actual, Expected):
        '''
        Compare Actual and Expected value
        :return: True if Actual equal Expected value
        and False otherwise
        '''
        if Actual == Expected:
            return True
        else:
            return False

    def checkCommentExist(self, postID, id, name, email, body):
        '''
        Verify that comment with specific parameters exist in specific post ID
        :return: True if the comment exist
        and False otherwise
        '''
        commentsList = self.getCommentsOfSpecificPostId(postID)
        for comment in commentsList:
            verifyID = self.verifyActualVSExpected(comment['id'], id)
            verifyName = self.verifyActualVSExpected(comment['name'], name)
            verifyEmail = self.verifyActualVSExpected(comment['email'], email)
            verifyBody = self.verifyActualVSExpected(comment['body'], body)
            if verifyID and verifyEmail and verifyName and verifyBody:
                return True

        return False



